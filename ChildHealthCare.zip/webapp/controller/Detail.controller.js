/*global location */
sap.ui.define([
	"DC/controller/BaseController",
	"jquery.sap.global",
	"sap/ui/model/json/JSONModel",
	"DC/model/formatter",
	"sap/m/UploadCollectionParameter",
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/m/TablePersoController",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV"
], function(BaseController, JQuery, JSONModel, formatter, UploadCollectionParameter, Controller, MessageToast, TablePersoController,
	Export, ExportTypeCSV) {
	"use strict";
	return BaseController.extend("DC.controller.Detail", {
		formatter: formatter,
		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */
		onInit: function() {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var oViewModel = new JSONModel({
				busy: false,
				delay: 0
			});
			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);
			this.setModel(oViewModel, "detailView");
			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
		},
		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */
		/**
		 * Event handler when the share by E-Mail button has been clicked
		 * @public
		 */
		onShareEmailPress: function() {
			var oViewModel = this.getModel("detailView");
			sap.m.URLHelper.triggerEmail(null, oViewModel.getProperty("/shareSendEmailSubject"), oViewModel.getProperty(
				"/shareSendEmailMessage"));
		},
		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function() {
			var oViewModel = this.getModel("detailView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},
		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */
		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			var sObjectId = oEvent.getParameter("arguments").objectId;
			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("Patients_Set", {
					PatientID: sObjectId
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));
		},
		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
		_bindView: function(sObjectPath) {
			// Set busy indicator during view binding
			var oViewModel = this.getModel("detailView");
			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);
			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},
		_onBindingChange: function() {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();
			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the master list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}
			var sPath = oElementBinding.getPath(),
				oResourceBundle = this.getResourceBundle(),
				oObject = oView.getModel().getObject(sPath),
				sObjectId = oObject.PatientID,
				sObjectName = oObject.Parentname,
				oViewModel = this.getModel("detailView");
			this.getOwnerComponent().oListSelector.selectAListItem(sPath);
			oViewModel.setProperty("/saveAsTileTitle", oResourceBundle.getText("shareSaveTileAppTitle", [sObjectName]));
			oViewModel.setProperty("/shareOnJamTitle", sObjectName);
			oViewModel.setProperty("/shareSendEmailSubject", oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage", oResourceBundle.getText("shareSendEmailObjectMessage", [
				sObjectName,
				sObjectId,
				location.href
			]));
		},
		_onMetadataLoaded: function() {
			// Store original busy indicator delay for the detail view
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView");
			// Make sure busy indicator is displayed immediately when
			// detail view is displayed for the first time
			oViewModel.setProperty("/delay", 0);
			// Binding the view will set it to not busy - so the view is always busy if it is not bound
			oViewModel.setProperty("/busy", true);
			// Restore original busy indicator delay for the detail view
			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		},
		/**
		 *@memberOf DC.controller.Detail
		 */
		onAddtoEMR: function(oEvent) {
			//This code was generated by the layout editor.
			var oModel = this.getOwnerComponent().getModel();
			var oNewEntry = null;
			var selectedPAtient = this.getView().getModel().getProperty("PatientID", oEvent.getSource().getBindingContext());
			var v_MHID = this.getView().getModel().getProperty("MHID", oEvent.getSource().getBindingContext());
			var oViewModel = this.getView("__xmlview0");
			var today = new Date();
			var year = today.getFullYear();
			var dd = today.getDate();
			if (dd < 10) {
				dd = "0" + dd;
			}
			var mm = today.getMonth() + 1;
			if (mm < 10) {
				mm = "0" + mm;
			}
			var today_s = year + "/" + mm + "/" + dd;
			var symp;
			var medi;
			for (var i = 1; i <= 5; i++) {
				var symp_id = "symptoms_" + i;
				var medi_id = "medicine_" + i;
				symp = oViewModel.byId(symp_id).getValue();
				medi = oViewModel.byId(medi_id).getValue();
				v_MHID = v_MHID + 1;
				if (symp !== undefined && symp !== null && symp.length > 0) {
					oNewEntry = {
						"PatientID": selectedPAtient,
						"MHID": v_MHID,
						"History": symp,
						"Date": today_s,
						"Medicine": medi
					};
					oModel.create("/MedicalHistory_Set", oNewEntry);
					symp = "";
				}
			}
			MessageToast.show("Above Records are added to EMR");
		},
		/**
		 *@memberOf DC.controller.Detail
		 */
		onPrint: function() {
			//This code was generated by the layout editor.
			MessageToast.show("Sent to Printer.");
		},
		/**
		 *@memberOf DC.controller.Detail
		 */
		onUpdateVDate: function() {
			//This code was generated by the layout editor.
			MessageToast.show("Vaccination Date is updated");
		},
		/**
		 *@memberOf DC.controller.Detail
		 */
		onExportData: function(oEvent) {
			var selectedPAtient = this.getView().getModel().getProperty("PatientID", oEvent.getSource().getBindingContext());
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter("PatientID", sap.ui.model.FilterOperator.EQ, selectedPAtient));
			var oExport = new Export({
				// Type that will be used to generate the content. Own ExportType's can be created to support other formats
				exportType: new ExportTypeCSV({
					separatorChar: ";"
				}),
				// Pass in the model created above
				models: this.getView().byId("__table1").getModel(),
				// binding information for the rows aggregation
				rows: {
					path: "/MedicalHistory_Set",
					filters: aFilter
				},
				// column definitions with column name and binding info for the content
				columns: [{
					name: "Date",
					template: {
						content: "{Date}"
					}
				}, {
					name: "Symptoms",
					template: {
						content: "{History}"
					}
				}, {
					name: "Medicine",
					template: {
						content: "{Medicine}"
					}
				}]
			});
			// download exported file
			oExport.saveFile().catch(function() {
				MessageToast.show("Error when downloading data. Browser might not be supported!\n\n");
			}).then(function() {
				oExport.destroy();
			});
			MessageToast.show("Data downloaded to Excel.");
		},
		/**
		 *@memberOf DC.controller.Detail
		 */
		onUpload: function() {
			//This code was generated by the layout editor.

		}
	});
});