jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 Patients_Set in the list

sap.ui.require([
	"sap/ui/test/Opa5",
	"DC/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"DC/test/integration/pages/App",
	"DC/test/integration/pages/Browser",
	"DC/test/integration/pages/Master",
	"DC/test/integration/pages/Detail",
	"DC/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "DC.view."
	});

	sap.ui.require([
		"DC/test/integration/MasterJourney",
		"DC/test/integration/NavigationJourney",
		"DC/test/integration/NotFoundJourney",
		"DC/test/integration/BusyJourney",
		"DC/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});